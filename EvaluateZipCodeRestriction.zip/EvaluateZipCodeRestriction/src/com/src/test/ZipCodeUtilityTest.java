package com.src.test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import com.src.java.ZipCodeRange;
import com.src.java.ZipCodeUtility;

/*
 * This is a test class which has multiple test cases to test ZipCodeUtility method
 * @author Nuhendra Giri
 * 
 */
public class ZipCodeUtilityTest {

	@Test
	/*
	 * This method tests whether list of provided ranges still remains the same
	 * if there is no overlap
	 * 
	 */
	public void testMergeRangeWithoutOverlap() {
		List<ZipCodeRange> testRanges = new ArrayList<ZipCodeRange>();
		List<ZipCodeRange> result = new ArrayList<ZipCodeRange>();

		testRanges.add(new ZipCodeRange(94133, 94133));
		testRanges.add(new ZipCodeRange(94200, 94299));
		testRanges.add(new ZipCodeRange(94600, 94699));

		result.add(new ZipCodeRange(94133, 94133));
		result.add(new ZipCodeRange(94200, 94299));
		result.add(new ZipCodeRange(94600, 94699));

		Assert.assertEquals(result.get(0), ZipCodeUtility.EvaluateZipCode(testRanges).get(0));
		Assert.assertEquals(result.get(1), ZipCodeUtility.EvaluateZipCode(testRanges).get(1));
		Assert.assertEquals(result.get(2), ZipCodeUtility.EvaluateZipCode(testRanges).get(2));

	}

	@Test
	/*
	 * This method tests whether list of provided ranges changes if there is an
	 * overlap.
	 * 
	 */
	public void testMergeRangeWithOverlap() {
		List<ZipCodeRange> testRanges = new ArrayList<ZipCodeRange>();
		List<ZipCodeRange> result = new ArrayList<ZipCodeRange>();

		testRanges.add(new ZipCodeRange(94133, 94133));
		testRanges.add(new ZipCodeRange(94200, 94299));
		testRanges.add(new ZipCodeRange(94226, 94399));

		result.add(new ZipCodeRange(94133, 94133));
		result.add(new ZipCodeRange(94200, 94399));

		Assert.assertEquals(result.get(0), ZipCodeUtility.EvaluateZipCode(testRanges).get(0));
		Assert.assertEquals(result.get(1).getStart(), ZipCodeUtility.EvaluateZipCode(testRanges).get(1).getStart());
		Assert.assertEquals(result.get(1).getEnd(), ZipCodeUtility.EvaluateZipCode(testRanges).get(1).getEnd());

	}

	@Test
	/*
	 * This method tests EvaluateZipCode method when provided an empty range
	 * 
	 */
	public void testMergeRangeZeroItem() {
		List<ZipCodeRange> testRanges = new ArrayList<ZipCodeRange>();
		List<ZipCodeRange> result = new ArrayList<ZipCodeRange>();

		Assert.assertEquals(result, ZipCodeUtility.EvaluateZipCode(testRanges));

	}

	@Test
	/*
	 * This method tests EvaluateZipCode method when provided single range
	 * 
	 */
	public void testMergeRangeOne() {
		List<ZipCodeRange> testRanges = new ArrayList<ZipCodeRange>();
		List<ZipCodeRange> result = new ArrayList<ZipCodeRange>();

		testRanges.add(new ZipCodeRange(100, 150));
		result.add(new ZipCodeRange(100, 150));

		Assert.assertEquals(result.get(0), ZipCodeUtility.EvaluateZipCode(testRanges).get(0));

	}

}
