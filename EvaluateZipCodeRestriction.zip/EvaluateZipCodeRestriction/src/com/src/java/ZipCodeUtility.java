package com.src.java;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

/*
 * This is a utility class to perform various operations
 *  on the provided zip code list
 * @author Nuhendra Giri
 */
public class ZipCodeUtility {

	/*
	 * This is a static method which evaluates zip codes and find out whether
	 * there is any overlap with in the provided range.
	 * 
	 * @param myRangeList List of ranges of zipcodes to evaluate
	 * 
	 * @return mergeList the List of ranges of zipcodes which are merged if
	 * there is any overlap
	 */
	public static List<ZipCodeRange> EvaluateZipCode(List<ZipCodeRange> myRangeList) {

		if (myRangeList.isEmpty() || myRangeList.size() == 1)
			return myRangeList;

		ArrayList<ZipCodeRange> mergeList = new ArrayList<ZipCodeRange>();

		Stack<ZipCodeRange> myStack = new Stack<ZipCodeRange>();
		myStack.push(myRangeList.get(0));

		for (int i = 1; i < myRangeList.size(); i++) {

			ZipCodeRange top = myStack.peek();
			ZipCodeRange current = myRangeList.get(i);

			if (current.getStart() >= top.getEnd())
				myStack.push(current);

			if (current.getStart() < top.getEnd()) {

				if (current.getEnd() > top.getEnd())
					top.setEnd(current.getEnd());

				myStack.pop();
				myStack.push(top);

			}

		}

		while (!myStack.isEmpty()) {
			mergeList.add(myStack.pop());
		}

		Collections.sort(mergeList, new ZipCodeRangeComparator());
		return mergeList;
	}

}
