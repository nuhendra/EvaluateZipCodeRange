package com.src.java;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/*This is a main class which is responsible
 *  to take user input and print out result
 *  
 *  @author Nuhendra Giri
 *  
 */

public class EvaluateZipCodeRestrictionMain {

	/*
	 * This main method is responsible for taking user input and printing out
	 * the result after performing operation
	 * 
	 * @author Nuhendra Giri
	 */
	public static void main(String[] args) {

		List<ZipCodeRange> myRangeList = new ArrayList<ZipCodeRange>();

		Scanner input = new Scanner(System.in);
		int start;
		int end;

		while (true) {
			System.out.println("Enter starting value of zip code range ");
			try {
				start = input.nextInt();
			} catch (Throwable t) {
				t.printStackTrace();
				break;
			}
			System.out.println("Enter ending value of zip code range ");
			try {
				end = input.nextInt();
			}

			catch (Throwable t) {
				t.printStackTrace();
				break;
			}

			myRangeList.add(new ZipCodeRange(start, end));

			System.out.println(
					"Start Value" + "\t" + start + "," + "End Value" + "\t" + end + "\t" + "Added to the list");
			System.out.println("Press 0 to exit and any other key to add values ");

			if (input.nextInt() == 0)
				break;

		}

		input.close();

		/*
		 * myRangeList.add(new ZipCodeRange(94133, 94133)); myRangeList.add(new
		 * ZipCodeRange(94200, 94299)); myRangeList.add(new ZipCodeRange(94226,
		 * 94699));
		 */

		Collections.sort(myRangeList, new ZipCodeRangeComparator());

		List<ZipCodeRange> mergedList = ZipCodeUtility.EvaluateZipCode(myRangeList);
		System.out.println("Printing out the merged list.");
		for (ZipCodeRange range : mergedList)

		{
			System.out.println("{" + range.getStart() + "," + range.getEnd() + "}");
		}

	}

}
