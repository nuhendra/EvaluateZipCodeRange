package com.src.java;

/*
 * This is a JAVA Bean class which holds start and end values of 
 * JAVA Code Range
 * @author Nuhendra Giri
 */
public class ZipCodeRange {

	private int start;
	private int end;

	public ZipCodeRange(int start, int end) {
		this.start = start;
		this.end = end;
	}

	/*
	 * @return start value of the zip code range
	 */
	public int getStart() {
		return start;
	}

	/*
	 * @param start value of the zip code range
	 */
	public void setStart(int start) {
		this.start = start;
	}

	/*
	 * @return end value of the zip code range
	 */
	public int getEnd() {
		return end;
	}

	/*
	 * @param end value of the zip code range
	 */
	public void setEnd(int end) {
		this.end = end;
	}

	@Override
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object) This method is responsible
	 * for performing shallow comparision between objects
	 * 
	 */
	public boolean equals(Object obj) {

		if (obj == this) {
			return true;
		}

		if (!(obj instanceof ZipCodeRange)) {
			return false;
		}

		ZipCodeRange range = (ZipCodeRange) obj;

		return range.getStart() == this.getStart() && range.getEnd() == this.getEnd();

	}

	@Override
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode() This method overrides default hascode
	 * methods and computes hashcode based on new input
	 */
	public int hashCode() {
		int result = 17;
		result = 31 * result + this.getStart();
		result = 31 * result + this.getEnd();
		return result;
	}

}
