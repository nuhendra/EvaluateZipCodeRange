package com.src.java;

import java.util.Comparator;

/*
 * This class is responsible for comparing two objects of type ZipCodeRange 
 * and is used for sorting
 * 
 * @author Nuhendra Giri
 */
public class ZipCodeRangeComparator implements Comparator<ZipCodeRange> {

	@Override
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 * 
	 * @param o1 the first ZipCodeRange object to compare
	 * 
	 * @param o2 the second ZipCodeRange object to compare
	 * 
	 * @return 0 if start value of two object is same, 1 if start value of first
	 * object is greater than start value of second object and -1 if start value
	 * of second object is greater than first object
	 */
	public int compare(ZipCodeRange o1, ZipCodeRange o2) {

		if (o1.getStart() > o2.getStart())
			return 1;
		else if (o1.getStart() == o2.getStart())
			return 0;

		else
			return -1;
	}

}
