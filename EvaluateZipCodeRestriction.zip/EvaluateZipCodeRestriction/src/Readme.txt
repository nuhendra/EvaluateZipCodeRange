This file contains detail explanation about the functionality provided by the program.

The program basically contains 4 java classes and 1 test class. The classes are as follows:

1.EvaluateZipCodeRestrictionMain
2.ZipCodeRange
3.ZipCodeRangeComparator
4.ZipCodeUtility
5.ZipCodeUtilityTest

Below is the detail explanation about the functionality of the classes.

1. EvaluateZipCodeRestrictionMain
   This is the main class of the program and the entry point to other functionality offered. 
   This class contains program which takes zip code ranges as user input from console and adds them to the list. The list is sorted 
   on the basis of start point of the zip code range. ZipCodeRangeComparator which is an implementation of
   comparator interface offers necessary functionality to sort the zip codes in the list.
   Then the static method EvaluateZipCode inside Utility class ZipCodeUtility is called to evaluate the zip code range 
   finding out the overlaps. After that the evaluated list of zip codes are printed in the console.
   
 2. ZipCodeRange
    This is a java bean class to reflect a range of zip code. It basically has two properties i.e, start point of the 
    zip code range and end point of zip code range. To assist other functionality like assert and compare, equals and
    hashcode method is overriden.
    
 3.  ZipCodeRangeComparator
     This is an implementation of Comparator interface and is used to compare two zipcode range objects.
 
 4.  ZipCodeUtility
     This class is the heart of the program and contains one static utility method EvaluateZipCode.
     EvaluateZipCode method takes list of ZipCodeRange object as argument and returns list of evaluated list of ZipCodeRange.
     This method basically looks for overlap in the provided list of ZipCodeRanges and if found overlap , then merges two ranges.
     Here, Stack data structure is used to find out overlap. The first item in the list is pushed into the stack and remaining items 
     are compared one by one using iteration. During iteration, it is checked whether end value of the item on top of the stack
     is greater than the start value of the item under current iteration. If found such item, end value of the item in the top of stack
     is changed with the current value and pushed to the top of stack. If not found such item, current item under
     iteration is pushed into the stack.
  
 5. ZipCodeUtilityTest
    This is a JUnit test class which contains several test methods to test the functionality.
    The four test methods test the functionality when there is overlap, when there is no overlap, 
    when there is no item in the list and when there is one item in the list.    
      